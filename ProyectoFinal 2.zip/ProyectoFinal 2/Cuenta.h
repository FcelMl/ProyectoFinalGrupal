#include <stdlib.h>
#include <stdio.h>
#include <iostream>
using namespace std;

class Cuenta{
	//ATRIBUTOS PRIVADOS
	private:
		long nCuenta;
		string tipoTarjeta;
		string cliente;
		int nip;
		float saldo;
		
	//METODOS PUBLICOS
	public:
		Cuenta(); //CONSTRUCTOR
		//METODOS SETTERS
		void setNCuenta(long);
		void setTipoTarjeta(string);
		void setCliente(string);
		void setNIP(int);
		void setSaldo(float);
		
		//METODOS GETTERS
		long getNCuenta();
		string getTipoTarjeta();
		string getCliente();
		int getNIP();
		float getSaldo();
		//DEMAS METODOS
		void crearCuenta(string);
		void mostrarCuentas();
		int verificarNCuenta(long);
};

Cuenta::Cuenta(){	
}

//METODOS SETTERS
void Cuenta::setNCuenta(long _nCuenta){
	nCuenta = _nCuenta;
}

void Cuenta::setTipoTarjeta(string _tipoTarjeta){
	tipoTarjeta = _tipoTarjeta;
}

void Cuenta::setCliente(string _cliente){
	cliente = _cliente;
}

void Cuenta::setNIP(int _nip){
	nip = _nip;
}

void Cuenta::setSaldo(float _saldo){
	saldo = _saldo;
}

//METODOS GETTERS
long Cuenta::getNCuenta(){
	return nCuenta;
}

string Cuenta::getTipoTarjeta(){
	return tipoTarjeta;
}

string Cuenta::getCliente(){
	return cliente;
}

int Cuenta::getNIP(){
	return nip;
}

float Cuenta::getSaldo(){
	return saldo;
}

//DEMAS METODOS
void Cuenta::crearCuenta(string n){
	string tarjeta;
	long n_cuenta;
	
	cout << " Ingrese ID cuenta: ";
	cin >> n_cuenta;
	setNCuenta(n_cuenta);
	
	setCliente(n);
	setSaldo(0);
	
	cin.ignore();
	cout << " Ingrese tipo de tarjeta:       ";
	getline(cin,tarjeta);
	setTipoTarjeta(tarjeta);
	
	cout << " Cuenta creada correctamente. Presione una tecla para continuar..";
	getch();
}

void Cuenta::mostrarCuentas(){
	system("cls");
	cout << endl << "\t\t\t      SISTEMA BANCARIO" << endl << endl;
	cout << " CUENTAS CREADAS" << endl << endl;
	cout << " ID Cuenta:         " << getNCuenta() << endl;
	cout << " Nombre de Cliente: " << getCliente() << endl;
	cout << " Tipo de Tarjeta:   " << getTipoTarjeta() << endl;
	cout << " Saldo Actual:      " << getSaldo() << endl;
	
	
	cout << endl << "Presione una tecla para continuar..";
	getch();
}

int Cuenta::verificarNCuenta(long _id){
	int encontro = 0;
	
	if (nCuenta == _id){
		encontro = 1;
	}
	return encontro;
}